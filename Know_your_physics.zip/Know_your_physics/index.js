var questionBank = 
[
  {
    "question": "Albert Einstein was awarded Nobel Prize for his path-breaking research and formulation of the:", 
    "answers": {
      "a":"Theory of Relavitity",
      "b":"Laws of Photo-Electric Effect"
    },
    "correct":"b",
  },
  {
    "question": "Which one of the following types of Laser is used in Laser Printers?", 
    "answers": {
      "a":"Semiconductor laser",
      "b":"Excimer Laser"
    },
    "correct":"a",
  },
  {
    "question": "The power of a lens is measured in :", 
    "answers": {
      "a":"diopters",
      "b":"lumen"
    },
    "correct":"a",
  },

  {
    "question": "If a moving body turns its speed to 1.5 times, what will be the impact on its kinetic energy?", 
    "answers": {
      "a":"will become 2.25 times",
      "b":"will become 3 times"
    },
    "correct":"a",
  },

  {
    "question": "If an egg with shell is placed in a microwave oven, which among the following would most likely happen?", 
    "answers": {
      "a":"The egg will get cooked slowly similar to a boiled egg",
      "b":"The egg will not get warmed"
    },
    "correct":"b",
  },
]
